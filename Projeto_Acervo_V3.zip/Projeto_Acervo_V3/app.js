class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-4">Desculpe, algo inesperado aconteceu.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [activeTab, setActiveTab] = React.useState('users');
    const [users, setUsers] = React.useState([]);
    const [products, setProducts] = React.useState([]);
    const [loans, setLoans] = React.useState([]);
    const [alert, setAlert] = React.useState(null);

    React.useEffect(() => {
      loadData();
    }, []);

    const loadData = async () => {
      const usersData = await dbGetUsers();
      const productsData = await dbGetProducts();
      const loansData = await dbGetLoans();
      setUsers(usersData);
      setProducts(productsData);
      setLoans(loansData);
    };

    const showAlert = (message, type = 'success') => {
      setAlert({ message, type });
      setTimeout(() => setAlert(null), 3000);
    };

    return (
      <div className="min-h-screen" data-name="app" data-file="app.js">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="max-w-7xl mx-auto px-4 py-8">
          {activeTab === 'users' && (
            <UserManagement users={users} loadData={loadData} showAlert={showAlert} />
          )}
          {activeTab === 'products' && (
            <ProductManagement products={products} loadData={loadData} showAlert={showAlert} />
          )}
          {activeTab === 'loans' && (
            <LoanManagement 
              loans={loans} 
              users={users} 
              products={products} 
              loadData={loadData} 
              showAlert={showAlert} 
            />
          )}
          {activeTab === 'reports' && (
            <Reports 
              users={users} 
              products={products} 
              loans={loans} 
              showAlert={showAlert} 
            />
          )}
        </main>

        {alert && <Alert message={alert.message} type={alert.type} />}
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);