function ProductForm({ onClose, loadData, showAlert, editData, onCreated }) {
  try {
    const [formData, setFormData] = React.useState({
      name: editData?.name || '',
      description: editData?.description || '',
      category: editData?.category || '',
      photo: editData?.photo || '',
      quantity: editData?.quantity || 1
    });

    React.useEffect(() => {
      setFormData({
        name: editData?.name || '',
        description: editData?.description || '',
        category: editData?.category || '',
        photo: editData?.photo || '',
        quantity: editData?.quantity || 1
      });
    }, [editData]);

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (!formData.name || !formData.category) {
        showAlert('Preencha todos os campos obrigatórios', 'error');
        return;
      }
      if (editData) {
        await dbUpdateProduct(editData.id, formData);
        showAlert('Produto atualizado com sucesso!');
      } else {
        const created = await dbCreateProduct(formData);
        showAlert('Produto cadastrado com sucesso!');
        if (onCreated) {
          try { onCreated(created); } catch (e) { console.error('onCreated callback error', e); }
        }
      }
      await loadData();
      onClose();
    };

    const handleFileUpload = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData({ ...formData, photo: reader.result });
        };
        reader.readAsDataURL(file);
      }
    };

    return (
      <div className="card p-6 mb-6" data-name="product-form" data-file="components/ProductForm.js">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">{editData ? 'Editar Produto' : 'Novo Produto'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <div className="icon-x text-lg"></div>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Nome do Produto *</label>
            <input
              type="text"
              className="input-field"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Descrição</label>
            <textarea
              className="input-field"
              rows="3"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Categoria *</label>
            <input
              type="text"
              className="input-field"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Quantidade em Estoque *</label>
            <input
              type="number"
              min="0"
              className="input-field"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 0 })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Foto do Produto</label>
            <input
              type="file"
              accept="image/*"
              className="input-field"
              onChange={handleFileUpload}
            />
            {formData.photo && (
              <img src={formData.photo} alt="Preview" className="mt-2 w-32 h-32 rounded-lg object-cover" />
            )}
          </div>

          <div className="flex gap-3 pt-4">
            <button type="submit" className="btn-primary flex-1">
              {editData ? 'Atualizar' : 'Cadastrar'}
            </button>
            <button type="button" onClick={onClose} className="px-6 py-2.5 border rounded-lg hover:bg-gray-50">
              Cancelar
            </button>
          </div>
        </form>
      </div>
    );
  } catch (error) {
    console.error('ProductForm component error:', error);
    return null;
  }
}