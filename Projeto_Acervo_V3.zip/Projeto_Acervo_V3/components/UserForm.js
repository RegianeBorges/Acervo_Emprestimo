function UserForm({ onClose, loadData, showAlert, editData, onCreated, autoFocus }) {
  try {
    const nameRef = React.useRef(null);

    const formatCpfInput = (value) => {
      const digits = (value || '').replace(/\D/g, '').slice(0, 11);
      let formatted = digits;
      if (digits.length > 9) {
        formatted = digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
      } else if (digits.length > 6) {
        formatted = digits.replace(/(\d{3})(\d{3})(\d{1,3})/, '$1.$2.$3');
      } else if (digits.length > 3) {
        formatted = digits.replace(/(\d{3})(\d{1,3})/, '$1.$2');
      }
      return formatted;
    };

    const validateCPF = (cpf) => {
      if (!cpf) return false;
      const str = cpf.replace(/\D/g, '');
      if (str.length !== 11) return false;
      if (/^(\d)\1+$/.test(str)) return false; // all digits equal

      const digits = str.split('').map(d => parseInt(d, 10));

      // Validate first digit
      let sum = 0;
      for (let i = 0; i < 9; i++) {
        sum += digits[i] * (10 - i);
      }
      let rev = 11 - (sum % 11);
      if (rev === 10 || rev === 11) rev = 0;
      if (rev !== digits[9]) return false;

      // Validate second digit
      sum = 0;
      for (let i = 0; i < 10; i++) {
        sum += digits[i] * (11 - i);
      }
      rev = 11 - (sum % 11);
      if (rev === 10 || rev === 11) rev = 0;
      if (rev !== digits[10]) return false;

      return true;
    };

    const [formData, setFormData] = React.useState({
      name: editData?.name || '',
      email: editData?.email || '',
      phone: editData?.phone || '',
      photo: editData?.photo || '',
      cpf: editData?.cpf ? formatCpfInput(editData.cpf) : ''
    });

    React.useEffect(() => {
      setFormData({
        name: editData?.name || '',
        email: editData?.email || '',
        phone: editData?.phone || '',
        photo: editData?.photo || '',
        cpf: editData?.cpf ? formatCpfInput(editData.cpf) : ''
      });
    }, [editData]);

    React.useEffect(() => {
      if (autoFocus && nameRef.current) {
        nameRef.current.focus();
      }
    }, [autoFocus]);

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (!formData.name || !formData.email || !formData.cpf) {
        showAlert('Preencha todos os campos obrigatórios', 'error');
        return;
      }

      if (!validateCPF(formData.cpf)) {
        showAlert('CPF inválido', 'error');
        return;
      }

      const saveData = { ...formData, cpf: formData.cpf.replace(/\D/g, '') };

      if (editData) {
        await dbUpdateUser(editData.id, saveData);
        showAlert('Usuário atualizado com sucesso!');
      } else {
        const created = await dbCreateUser(saveData);
        showAlert('Usuário cadastrado com sucesso!');
        if (onCreated) {
          try { onCreated(created); } catch (e) { console.error('onCreated callback error', e); }
        }
      }
      await loadData();
      onClose();
    };

    const handleFileUpload = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData({ ...formData, photo: reader.result });
        };
        reader.readAsDataURL(file);
      }
    };

    return (
      <div className="card p-6 mb-6" data-name="user-form" data-file="components/UserForm.js">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">{editData ? 'Editar Usuário' : 'Novo Usuário'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg" aria-label="Fechar modal">
            <div className="icon-x text-lg"></div>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Nome *</label>
            <input
              ref={nameRef}
              type="text"
              className="input-field"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email *</label>
            <input
              type="email"
              className="input-field"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">CPF *</label>
            <input
              type="text"
              inputMode="numeric"
              className="input-field"
              value={formData.cpf}
              onChange={(e) => setFormData({ ...formData, cpf: formatCpfInput(e.target.value) })}
              placeholder="000.000.000-00"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Telefone</label>
            <input
              type="tel"
              className="input-field"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Foto</label>
            <input
              type="file"
              accept="image/*"
              className="input-field"
              onChange={handleFileUpload}
            />
            {formData.photo && (
              <img src={formData.photo} alt="Preview" className="mt-2 w-24 h-24 rounded-full object-cover" />
            )}
          </div>

          <div className="flex gap-3 pt-4">
            <button type="submit" className="btn-primary flex-1">
              {editData ? 'Atualizar' : 'Cadastrar'}
            </button>
            <button type="button" onClick={onClose} className="px-6 py-2.5 border rounded-lg hover:bg-gray-50">
              Cancelar
            </button>
          </div>
        </form>
      </div>
    );
  } catch (error) {
    console.error('UserForm component error:', error);
    return null;
  }
}