function LoanCard({ loan, users, products, onReturn, onEdit, onDelete }) {
  try {
    const user = users.find(u => u.id === loan.userId);
    const product = products.find(p => p.id === loan.productId);

    const getStatusInfo = () => {
      if (loan.status === 'returned') {
        return { label: `Devolvido em ${loan.returnDate ? new Date(loan.returnDate).toLocaleDateString('pt-BR') : ''}`, className: 'text-green-600' };
      }
      const now = new Date();
      const due = loan.dueDate ? new Date(loan.dueDate) : null;
      if (due && now > due) {
        return { label: 'Atrasado', className: 'text-red-600' };
      }
      return { label: 'Em dia', className: 'text-blue-600' };
    };

    const statusInfo = getStatusInfo();

    return (
      <div className="card p-6" data-name="loan-card" data-file="components/LoanCard.js">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <img 
                src={user?.photo || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50'} 
                alt={user?.name}
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <h3 className="font-semibold text-[var(--text-color)]">{user?.name}</h3>
                <p className="text-sm text-gray-600">{user?.email}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 ml-15 mb-3">
              <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                <div className="icon-arrow-right text-lg text-gray-600"></div>
              </div>
              <div>
                <p className="font-medium text-[var(--text-color)]">{product?.name}</p>
                <p className="text-sm text-gray-600">{product?.category}</p>
              </div>
            </div>

            <div className="flex items-center gap-6 ml-15">
              <div className="flex items-center gap-2">
                <div className="icon-calendar text-base text-gray-500"></div>
                <span className="text-sm text-gray-600">
                  {new Date(loan.loanDate).toLocaleDateString('pt-BR')}
                </span>
              </div>

              {loan.dueDate && (
                <div className="flex items-center gap-2">
                  <div className="icon-clock text-base text-gray-500"></div>
                  <span className="text-sm text-gray-600">Prazo: {loan.prazo || '-'} dias — Devolver até {new Date(loan.dueDate).toLocaleDateString('pt-BR')}</span>
                </div>
              )}

              <div className={`flex items-center gap-2 text-sm font-medium ${statusInfo.className}`}>
                <div className="icon-info text-base" />
                {statusInfo.label}
              </div>

              {loan.status === 'active' && (
                <button
                  onClick={() => onReturn(loan.id)}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                >
                  Devolver
                </button>
              )}

              {loan.status === 'returned' && (
                <span className="flex items-center gap-2 text-sm text-green-600">
                  <div className="icon-check-circle text-base"></div>
                  Devolvido em {loan.returnDate ? new Date(loan.returnDate).toLocaleDateString('pt-BR') : ''}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-2 ml-4">
            <button onClick={() => onEdit && onEdit(loan)} title="Editar" aria-label="Editar empréstimo" className="w-10 h-10 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center transition-colors">
              <div className="icon-pencil text-lg text-blue-600"></div>
            </button>
            <button onClick={() => onDelete && onDelete(loan.id)} title="Excluir" aria-label="Excluir empréstimo" className="w-10 h-10 rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors">
              <div className="icon-trash-2 text-lg text-red-600"></div>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoanCard component error:', error);
    return null;
  }
}

// Hook local de debounce
function useDebounce(value, delay = 250) {
  const [debounced, setDebounced] = React.useState(value);
  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

function LoanManagement({ loans, users, products, loadData, showAlert }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [editingLoan, setEditingLoan] = React.useState(null);
    const [query, setQuery] = React.useState('');

    const debouncedQuery = useDebounce(query, 250);

    // New filter states
    const [filterStatus, setFilterStatus] = React.useState('all'); // all | active | returned
    const [filterOverdue, setFilterOverdue] = React.useState(false);
    const [filterFromDate, setFilterFromDate] = React.useState(''); // yyyy-mm-dd
    const [filterToDate, setFilterToDate] = React.useState('');

    const handleReturn = async (loanId) => {
      await dbReturnLoan(loanId);
      await loadData();
      showAlert('Produto devolvido com sucesso!');
    };

    const handleEdit = (loan) => {
      setEditingLoan(loan);
      setShowForm(true);
    };

    const handleCloseForm = () => {
      setEditingLoan(null);
      setShowForm(false);
    };

    const handleDelete = async (loanId) => {
      if (confirm('Tem certeza que deseja excluir este empréstimo?')) {
        await dbDeleteLoan(loanId);
        await loadData();
        showAlert('Empréstimo excluído com sucesso!');
      }
    };

    const userMap = React.useMemo(() => {
      const m = {};
      (users || []).forEach(u => { m[u.id] = u.name; });
      return m;
    }, [users]);

    const userObjMap = React.useMemo(() => {
      const m = {};
      (users || []).forEach(u => { m[u.id] = u; });
      return m;
    }, [users]);

    const productMap = React.useMemo(() => {
      const m = {};
      (products || []).forEach(p => { m[p.id] = p.name; });
      return m;
    }, [products]);

    const now = React.useMemo(() => new Date(), []);

    const isLoanOverdue = (l) => {
      if (!l) return false;
      if (l.status === 'returned') return false;
      if (!l.dueDate) return false;
      try {
        const due = new Date(l.dueDate);
        return now > due;
      } catch (e) { return false; }
    };

    // generic matcher used earlier
    const dateVariants = (iso) => {
      if (!iso) return [];
      try {
        const d = new Date(iso);
        const pt = d.toLocaleDateString('pt-BR');
        const isoS = d.toISOString();
        const ddmmyyyy = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
        const ddmmyyyyDash = `${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`;
        return [pt.toLowerCase(), isoS.toLowerCase(), ddmmyyyy.toLowerCase(), ddmmyyyyDash.toLowerCase()];
      } catch (e) {
        return [];
      }
    };

    const matchLoan = (l, term, termDigits) => {
      const uName = (userMap[l.userId] || '').toLowerCase();
      const pName = (productMap[l.productId] || '').toLowerCase();
      const pObj = products.find(p => p.id === l.productId) || {};
      const uObj = userObjMap[l.userId] || {};

      if (!term) return true;
      if ((l.id || '').toLowerCase().includes(term)) return true;
      if (uName.includes(term) || pName.includes(term)) return true;
      if ((uObj.email || '').toLowerCase().includes(term)) return true;
      if ((pObj.category || '').toLowerCase().includes(term)) return true;
      if ((pObj.description || '').toLowerCase().includes(term)) return true;
      if ((l.status || '').toLowerCase().includes(term)) return true;

      const loanDates = [].concat(dateVariants(l.loanDate), dateVariants(l.dueDate), dateVariants(l.returnDate));
      for (const ds of loanDates) {
        if (ds.includes(term)) return true;
      }

      if (termDigits) {
        if ((uObj.cpf || '').replace(/\D/g, '').includes(termDigits)) return true;
        if ((l.id || '').includes(termDigits)) return true;
      }

      return false;
    };

    // apply search + filters to the full list and partition
    const filteredLoansAll = React.useMemo(() => {
      const term = (debouncedQuery || '').trim().toLowerCase();
      const termDigits = (debouncedQuery || '').replace(/\D/g, '');

      const from = filterFromDate ? new Date(filterFromDate) : null;
      const to = filterToDate ? new Date(filterToDate) : null;

      return (loans || []).filter(l => {
        // search match
        if (!matchLoan(l, term, termDigits)) return false;
        // status filter
        if (filterStatus === 'active' && l.status !== 'active') return false;
        if (filterStatus === 'returned' && l.status !== 'returned') return false;
        // overdue filter
        if (filterOverdue && !isLoanOverdue(l)) return false;
        // date range filter (loanDate)
        if (from) {
          const ld = l.loanDate ? new Date(l.loanDate) : null;
          if (!ld || ld < from) return false;
        }
        if (to) {
          const ld = l.loanDate ? new Date(l.loanDate) : null;
          if (!ld || ld > new Date(to.getFullYear(), to.getMonth(), to.getDate(),23,59,59,999)) return false;
        }
        return true;
      });
    }, [loans, debouncedQuery, filterStatus, filterOverdue, filterFromDate, filterToDate, users, products]);

    const filteredActive = React.useMemo(() => filteredLoansAll.filter(l => l.status === 'active'), [filteredLoansAll]);
    const filteredReturned = React.useMemo(() => filteredLoansAll.filter(l => l.status === 'returned'), [filteredLoansAll]);

    const clearFilters = () => {
      setFilterStatus('all');
      setFilterOverdue(false);
      setFilterFromDate('');
      setFilterToDate('');
    };

    return (
      <div id="loans-section" data-name="loan-management" data-file="components/LoanCard.js">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Empréstimos</h2>
          <button onClick={() => setShowForm(!showForm)} className="btn-primary">
            <span className="flex items-center gap-2">
              <div className="icon-plus text-lg"></div>
              Novo Empréstimo
            </span>
          </button>
        </div>

        {/* Filters panel */}
        <div className="card p-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-end md:gap-4">
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Status</label>
                <select className="input-field" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                  <option value="all">Todos</option>
                  <option value="active">Ativos</option>
                  <option value="returned">Devolvidos</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Atrasados</label>
                <div className="flex items-center gap-2">
                  <input id="filter-overdue" type="checkbox" checked={filterOverdue} onChange={(e) => setFilterOverdue(e.target.checked)} />
                  <label htmlFor="filter-overdue" className="text-sm text-gray-700">Apenas atrasados</label>
                </div>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Período (data empréstimo)</label>
                <div className="flex gap-2">
                  <input type="date" className="input-field" value={filterFromDate} onChange={(e) => setFilterFromDate(e.target.value)} />
                  <input type="date" className="input-field" value={filterToDate} onChange={(e) => setFilterToDate(e.target.value)} />
                </div>
              </div>
            </div>

            <div className="mt-3 md:mt-0 flex items-center gap-2">
              <button onClick={clearFilters} className="px-4 py-2 border rounded-lg">Limpar filtros</button>
              <button onClick={() => { /* keep filters applied automatically */ }} className="px-4 py-2 bg-blue-600 text-white rounded-lg">Aplicar</button>
            </div>
          </div>
        </div>

        {showForm && (
          <LoanForm 
            onClose={handleCloseForm} 
            users={users} 
            products={products} 
            loadData={loadData} 
            showAlert={showAlert}
            editData={editingLoan}
          />
        )}

        <div className="space-y-6 mt-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">Ativos ({filteredActive.length})</h3>
            <div className="grid gap-4">
              {filteredActive.map(loan => (
                <LoanCard 
                  key={loan.id} 
                  loan={loan} 
                  users={users} 
                  products={products} 
                  onReturn={handleReturn} 
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
              {filteredActive.length ===0 && (
                <div className="text-center py-8 text-gray-500">
                  Nenhum empréstimo ativo
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Histórico ({filteredReturned.length})</h3>
            <div className="grid gap-4">
              {filteredReturned.map(loan => (
                <LoanCard 
                  key={loan.id} 
                  loan={loan} 
                  users={users} 
                  products={products} 
                  onReturn={handleReturn} 
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoanManagement component error:', error);
    return (
      <div className="p-6 bg-red-50 border border-red-200 rounded-lg text-red-700">
        <h3 className="font-semibold">Erro no módulo de Empréstimos</h3>
        <pre className="whitespace-pre-wrap text-sm mt-2">{String(error && (error.message || error))}</pre>
      </div>
    );
  }
}