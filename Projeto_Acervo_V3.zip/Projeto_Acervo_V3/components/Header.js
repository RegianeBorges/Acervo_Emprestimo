function Header({ activeTab, setActiveTab }) {
  try {
    const tabs = [
      { id: 'users', label: 'Usuários', icon: 'users' },
      { id: 'products', label: 'Produtos', icon: 'package' },
      { id: 'loans', label: 'Empréstimos', icon: 'arrow-right-left' },
      { id: 'reports', label: 'Relatórios', icon: 'file-bar-chart' }
    ];

    return (
      <header className="bg-white shadow-sm border-b border-[var(--border-color)]" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[var(--primary-color)] flex items-center justify-center">
                <div className="icon-package text-xl text-white"></div>
              </div>
              <h1 className="text-xl font-bold text-[var(--text-color)]">Sistema de Acervo</h1>
            </div>
          </div>
          
          <nav className="flex gap-1 -mb-px">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-3 font-medium transition-all ${
                  activeTab === tab.id
                    ? 'text-[var(--primary-color)] border-b-2 border-[var(--primary-color)]'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <div className={`icon-${tab.icon} text-lg`}></div>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}