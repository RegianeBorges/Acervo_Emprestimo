function Reports({ users, products, loans, showAlert }) {
  try {
    const activeLoans = loans.filter(l => l.status === 'active');
    const returnedLoans = loans.filter(l => l.status === 'returned');

    const [listModal, setListModal] = React.useState({ open: false, type: '', data: [], title: '' });
    const [listFilterQuery, setListFilterQuery] = React.useState('');

    // hook local de debounce
    function useDebounce(value, delay = 250) {
      const [debounced, setDebounced] = React.useState(value);
      React.useEffect(() => {
        const t = setTimeout(() => setDebounced(value), delay);
        return () => clearTimeout(t);
      }, [value, delay]);
      return debounced;
    }

    const debouncedListFilter = useDebounce(listFilterQuery, 250);

    React.useEffect(() => {
      // Adiciona estilo para impressão que mostra apenas a área de impressão
      if (!document.getElementById('reports-print-style')) {
        const style = document.createElement('style');
        style.id = 'reports-print-style';
        style.innerHTML = `@media print { body * { visibility: hidden !important; } .print-area, .print-area * { visibility: visible !important; } .print-area { position: absolute; left: 0; top: 0; width: 100%; } }`;
        document.head.appendChild(style);
      }
    }, []);

    const handleExport = (data, filename, format) => {
      try {
        if (format === 'json') {
          exportToJSON(data, filename);
        } else if (format === 'csv') {
          exportToCSV(data, filename);
        }
        showAlert(`Dados exportados com sucesso em ${format.toUpperCase()}!`);
      } catch (error) {
        showAlert('Erro ao exportar dados', 'error');
      }
    };

    const openList = (type) => {
      let data = [];
      let title = '';
      switch (type) {
        case 'users':
          data = users || [];
          title = 'Lista de Usuários';
          break;
        case 'products':
          data = products || [];
          title = 'Lista de Produtos';
          break;
        case 'activeLoans':
          data = activeLoans || [];
          title = 'Empréstimos Ativos';
          break;
        case 'returnedLoans':
          data = returnedLoans || [];
          title = 'Devoluções (Histórico)';
          break;
        case 'allLoans':
          data = loans || [];
          title = 'Todos os Empréstimos';
          break;
        default:
          break;
      }
      setListFilterQuery('');
      setListModal({ open: true, type, data, title });
    };

    const closeModal = () => setListModal({ open: false, type: '', data: [], title: '' });

    const handlePrint = () => {
      // Pequeno atraso garante que DOM do modal esteja visível
      setTimeout(() => window.print(), 50);
    };

    const formatDate = (iso) => {
      if (!iso) return '';
      try { return new Date(iso).toLocaleString('pt-BR'); } catch (e) { return iso; }
    };

    const filterDataForModal = React.useMemo(() => {
      const q = (debouncedListFilter || '').trim().toLowerCase();
      const qDigits = (debouncedListFilter || '').replace(/\D/g, '');
      if (!q) return listModal.data || [];

      const userMap = {};
      (users || []).forEach(u => { userMap[u.id] = u; });
      const productMap = {};
      (products || []).forEach(p => { productMap[p.id] = p; });

      const dateMatches = (iso) => {
        if (!iso) return false;
        try {
          const d = new Date(iso);
          const pt = d.toLocaleDateString('pt-BR').toLowerCase();
          const isoS = d.toISOString().toLowerCase();
          const ddmmyyyy = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
          const ddmmyyyyDash = `${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`;
          return pt.includes(q) || isoS.includes(q) || ddmmyyyy.includes(q) || ddmmyyyyDash.includes(q);
        } catch (e) {
          return false;
        }
      };

      return (listModal.data || []).filter(item => {
        if (listModal.type === 'users') {
          const name = (item.name || '').toLowerCase();
          const email = (item.email || '').toLowerCase();
          const phone = (item.phone || '').toLowerCase();
          const cpf = (item.cpf || '').replace(/\D/g, '');
          const created = item.createdAt ? new Date(item.createdAt).toLocaleDateString('pt-BR').toLowerCase() : '';
          return name.includes(q) || email.includes(q) || phone.includes(q) || created.includes(q) || (qDigits && cpf.includes(qDigits));
        }

        if (listModal.type === 'products') {
          const name = (item.name || '').toLowerCase();
          const desc = (item.description || '').toLowerCase();
          const cat = (item.category || '').toLowerCase();
          const created = item.createdAt ? new Date(item.createdAt).toLocaleDateString('pt-BR').toLowerCase() : '';
          return name.includes(q) || desc.includes(q) || cat.includes(q) || created.includes(q);
        }

        // loans types
        const l = item;
        const u = userMap[l.userId] || {};
        const p = productMap[l.productId] || {};
        if (!q) return true;
        if ((l.id || '').toLowerCase().includes(q)) return true;
        if ((u.name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q)) return true;
        if ((p.name || '').toLowerCase().includes(q) || (p.category || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)) return true;
        if ((l.status || '').toLowerCase().includes(q)) return true;
        if (dateMatches(l.loanDate) || dateMatches(l.dueDate) || dateMatches(l.returnDate)) return true;
        if (qDigits && ((u.cpf || '').replace(/\D/g, '').includes(qDigits) || (l.id || '').includes(qDigits))) return true;
        return false;
      });
    }, [listModal, debouncedListFilter, users, products]);

    const renderTable = () => {
      const data = filterDataForModal;
      if (!data || data.length === 0) {
        return <div className="text-center py-8 text-gray-500">Nenhum registro para exibir</div>;
      }

      if (listModal.type === 'users') {
        return (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="border-b py-2">Nome</th>
                <th className="border-b py-2">Email</th>
                <th className="border-b py-2">CPF</th>
                <th className="border-b py-2">Telefone</th>
                <th className="border-b py-2">Cadastrado</th>
              </tr>
            </thead>
            <tbody>
              {data.map(u => (
                <tr key={u.id} className="align-top">
                  <td className="py-2 border-b">{u.name}</td>
                  <td className="py-2 border-b">{u.email}</td>
                  <td className="py-2 border-b">{u.cpf ? u.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : ''}</td>
                  <td className="py-2 border-b">{u.phone || ''}</td>
                  <td className="py-2 border-b">{formatDate(u.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        );
      }

      if (listModal.type === 'products') {
        return (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="border-b py-2">Nome</th>
                <th className="border-b py-2">Categoria</th>
                <th className="border-b py-2">Quantidade</th>
                <th className="border-b py-2">Cadastrado</th>
              </tr>
            </thead>
            <tbody>
              {data.map(p => (
                <tr key={p.id} className="align-top">
                  <td className="py-2 border-b">{p.name}</td>
                  <td className="py-2 border-b">{p.category}</td>
                  <td className="py-2 border-b">{p.quantity || 0}</td>
                  <td className="py-2 border-b">{formatDate(p.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        );
      }

      // Loans table (active/returned/all)
      if (listModal.type === 'activeLoans' || listModal.type === 'returnedLoans' || listModal.type === 'allLoans') {
        // Map ids to names for users/products to show readable info
        const userMap = {};
        (users || []).forEach(u => { userMap[u.id] = u.name; });
        const productMap = {};
        (products || []).forEach(p => { productMap[p.id] = p.name; });

        return (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="border-b py-2">Usuário</th>
                <th className="border-b py-2">Produto</th>
                <th className="border-b py-2">Data Empréstimo</th>
                <th className="border-b py-2">Prazo (dias)</th>
                <th className="border-b py-2">Data Devolução</th>
                <th className="border-b py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.map(l => (
                <tr key={l.id} className="align-top">
                  <td className="py-2 border-b">{userMap[l.userId] || l.userId}</td>
                  <td className="py-2 border-b">{productMap[l.productId] || l.productId}</td>
                  <td className="py-2 border-b">{formatDate(l.loanDate)}</td>
                  <td className="py-2 border-b">{l.prazo || '-'}</td>
                  <td className="py-2 border-b">{l.returnDate ? formatDate(l.returnDate) : (l.dueDate ? new Date(l.dueDate).toLocaleDateString('pt-BR') : '-')}</td>
                  <td className="py-2 border-b">{l.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        );
      }

      return null;
    };

    const ExportButtons = ({ data, filename }) => (
      <div className="flex gap-2">
        <button
          onClick={() => handleExport(data, filename, 'json')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center gap-2"
        >
          <div className="icon-download text-base"></div>
          JSON
        </button>
        <button
          onClick={() => handleExport(data, filename, 'csv')}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium flex items-center gap-2"
        >
          <div className="icon-download text-base"></div>
          CSV
        </button>
      </div>
    );

    return (
      <div id="reports-section" data-name="reports" data-file="components/Reports.js">
        <h2 className="text-2xl font-bold mb-6">Relatórios e Exportação</h2>

        <div className="grid gap-6">
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <div className="icon-users text-xl text-blue-600"></div>
                  Usuários
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Total de {users.length} usuários cadastrados
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => openList('users')} 
                className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors text-sm border border-yellow-400">Ver Lista</button>
                <ExportButtons data={users} filename="usuarios" />
              </div>
            </div>
          </div>

          

          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <div className="icon-package text-xl text-purple-600"></div>
                  Produtos
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Total de {products.length} produtos no acervo
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => openList('products')} 
                className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors text-sm border border-yellow-400">Ver Lista</button>
                <ExportButtons data={products} filename="produtos" />
              </div>
            </div>
          </div>

          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <div className="icon-arrow-right-left text-xl text-orange-600"></div>
                  Empréstimos Ativos
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Total de {activeLoans.length} empréstimos ativos
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => openList('activeLoans')} 
                className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors text-sm border border-yellow-400">Ver Lista</button>
                <ExportButtons data={activeLoans} filename="emprestimos-ativos" />
              </div>
            </div>
          </div>

          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <div className="icon-check-circle text-xl text-green-600"></div>
                  Devoluções (Histórico)
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Total de {returnedLoans.length} produtos devolvidos
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => openList('returnedLoans')} 
                className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors text-sm border border-yellow-400">Ver Lista</button>                
                
               <ExportButtons data={returnedLoans} filename="devolucoes" />
              </div>
            </div>
          </div>

          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <div className="icon-list text-xl text-gray-700"></div>
                  Todos os Empréstimos
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Total de {loans.length} empréstimos registrados
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => openList('allLoans')} 
                className="px-4 py-2 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors text-sm border border-yellow-400">Ver Lista</button>
                <ExportButtons data={loans} filename="emprestimos-todos" />
              </div>
            </div>
          </div>
        </div>

        {listModal.open && (
          <div className="fixed inset-0 z-50 flex items-start justify-center p-6">
            <div className="absolute inset-0 bg-black opacity-40" onClick={closeModal}></div>

            <div className="relative bg-white rounded-lg shadow-lg w-full max-w-5xl overflow-auto print-area p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{listModal.title}</h3>
                <div className="flex items-center gap-2">
                  <button onClick={handlePrint} className="px-4 py-2 bg-gray-800 text-white rounded-lg text-sm">Imprimir</button>
                  <button onClick={closeModal} className="px-4 py-2 border rounded-lg text-sm">Fechar</button>
                </div>
              </div>

              <div className="mb-4 flex items-center gap-3">
                <div className="relative flex-1">
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                    <div className="icon-search text-lg"></div>
                  </div>
                  <input
                    type="text"
                    className="input-field w-full pl-10 pr-10"
                    placeholder="Pesquisar na lista... (nome, email, produto, id, data, CPF)"
                    value={listFilterQuery}
                    onChange={(e) => setListFilterQuery(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Escape') setListFilterQuery(''); }}
                  />
                  {listFilterQuery ? (
                    <button
                      onClick={() => setListFilterQuery('')}
                      title="Limpar filtro"
                      className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1 text-gray-600 hover:text-gray-800"
                    >
                      <div className="icon-x text-lg"></div>
                    </button>
                  ) : null}
                </div>
                <div>
                  <button onClick={() => { /* também exportar a lista filtrada */ handleExport(filterDataForModal, listModal.title.replace(/\s+/g,'-').toLowerCase(), 'csv'); }} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Exportar Filtrada (CSV)</button>
                </div>
              </div>

              <div className="overflow-x-auto">
                {renderTable()}
              </div>

              <div className="mt-4 text-right text-sm text-gray-500">Gerado em {new Date().toLocaleString('pt-BR')}</div>
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('Reports component error:', error);
    return null;
  }
}