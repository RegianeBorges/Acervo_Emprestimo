function Modal({ open, onClose, title, children, initialFocusRef = null, size = 'max-w-2xl', showClose = true }) {
 const [visible, setVisible] = React.useState(false);
 const modalRef = React.useRef(null);

 // Detect visibility of element
 const isVisible = (el) => {
 if (!el) return false;
 // offsetParent null for display:none, also check bounding rect
 if (el.offsetParent === null) return false;
 const rects = el.getClientRects();
 return rects && rects.length >0;
 };

 React.useEffect(() => {
 let mounted = true;
 if (open) {
 // small timeout to allow CSS entry
 setTimeout(() => { if (mounted) setVisible(true); },20);

 // focus initial element or first focusable visible
 const focusTimeout = setTimeout(() => {
 try {
 if (initialFocusRef && initialFocusRef.current && isVisible(initialFocusRef.current)) {
 initialFocusRef.current.focus();
 return;
 }
 const node = modalRef.current;
 if (!node) return;
 const focusableSelectors = 'a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])';
 const els = Array.from(node.querySelectorAll(focusableSelectors)).filter(el => !el.hasAttribute('disabled') && isVisible(el));
 if (els.length) els[0].focus();
 } catch (e) {
 console.error('Modal focus error', e);
 }
 },50);

 // handle escape and trap focus
 const onKeyDown = (e) => {
 if (e.key === 'Escape') {
 e.preventDefault();
 onClose && onClose();
 }
 if (e.key === 'Tab') {
 const node = modalRef.current;
 if (!node) return;
 const focusable = Array.from(node.querySelectorAll('a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])')).filter(el => !el.hasAttribute('disabled') && isVisible(el));
 if (focusable.length ===0) {
 e.preventDefault();
 return;
 }
 const first = focusable[0];
 const last = focusable[focusable.length -1];
 if (e.shiftKey && document.activeElement === first) {
 e.preventDefault();
 last.focus();
 } else if (!e.shiftKey && document.activeElement === last) {
 e.preventDefault();
 first.focus();
 }
 }
 };

 document.addEventListener('keydown', onKeyDown);

 return () => {
 mounted = false;
 clearTimeout(focusTimeout);
 document.removeEventListener('keydown', onKeyDown);
 setVisible(false);
 };
 } else {
 setVisible(false);
 }
 return () => { mounted = false; };
 }, [open, initialFocusRef, onClose]);

 if (!open) return null;

 return (
 <div className="fixed inset-0 z-50 flex items-start justify-center p-6">
 <div className={`absolute inset-0 bg-black transition-opacity ${visible ? 'opacity-40' : 'opacity-0'}`} onClick={onClose}></div>

 <div ref={modalRef} className={`relative bg-white rounded-lg shadow-lg w-full ${size} overflow-auto p-6 transform transition-all duration-200 ${visible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`} role="dialog" aria-modal="true">
 <div className="flex items-center justify-between mb-4">
 {title ? <h4 className="font-semibold">{title}</h4> : null}
 {showClose && (
 <button onClick={onClose} className="p-2" aria-label="Fechar modal">
 <div className="icon-x text-lg"></div>
 </button>
 )}
 </div>

 <div>
 {children}
 </div>
 </div>
 </div>
 );
}