function Alert({ message, type = 'success' }) {
  try {
    const styles = {
      success: 'bg-green-50 text-green-800 border-green-200',
      error: 'bg-red-50 text-red-800 border-red-200'
    };

    const icons = {
      success: 'check-circle',
      error: 'alert-circle'
    };

    return (
      <div 
        className={`fixed top-4 right-4 px-6 py-4 rounded-lg border shadow-lg ${styles[type]} flex items-center gap-3 animate-slide-in z-50`}
        data-name="alert" 
        data-file="components/Alert.js"
      >
        <div className={`icon-${icons[type]} text-xl`}></div>
        <span className="font-medium">{message}</span>
      </div>
    );
  } catch (error) {
    console.error('Alert component error:', error);
    return null;
  }
}