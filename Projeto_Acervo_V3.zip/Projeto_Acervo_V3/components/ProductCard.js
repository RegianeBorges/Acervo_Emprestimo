function ProductCard({ product, onEdit, onDelete }) {
  try {
    const statusColors = {
      available: 'bg-green-100 text-green-700',
      loaned: 'bg-yellow-100 text-yellow-700'
    };

    return (
      <div className="card p-6" data-name="product-card" data-file="components/ProductCard.js">
        <div className="flex items-start gap-4">
          <img 
            src={product.photo || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=150'} 
            alt={product.name}
            className="w-24 h-24 rounded-lg object-cover"
          />
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-lg text-[var(--text-color)]">{product.name}</h3>
                <p className="text-gray-600 text-sm mt-1">{product.description}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                (product.quantity || 0) > 0 ? statusColors.available : statusColors.loaned
              }`}>
                {(product.quantity || 0) > 0 ? 'Disponível' : 'Indisponível'}
              </span>
            </div>
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
                  <div className="icon-tag text-base text-purple-600"></div>
                </div>
                <span className="text-sm text-gray-600">{product.category}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center">
                  <div className="icon-package text-base text-orange-600"></div>
                </div>
                <span className="text-sm text-gray-600">
                  Estoque: {product.quantity || 0}
                </span>
              </div>
            </div>
          </div>
          <div className="flex gap-2 items-start">
            <button
              onClick={() => onEdit(product)}
              title="Editar"
              aria-label="Editar produto"
              className="w-10 h-10 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center transition-colors"
            >
              <div className="icon-pencil text-lg text-blue-600"></div>
            </button>
            <button
              onClick={() => onDelete(product.id)}
              title="Excluir"
              aria-label="Excluir produto"
              className="w-10 h-10 rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors"
            >
              <div className="icon-trash-2 text-lg text-red-600"></div>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProductCard component error:', error);
    return null;
  }
}

// hook local de debounce
function useDebounce(value, delay = 250) {
  const [debounced, setDebounced] = React.useState(value);
  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

function ProductManagement({ products, loadData, showAlert }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [editingProduct, setEditingProduct] = React.useState(null);
    const [query, setQuery] = React.useState('');

    const debouncedQuery = useDebounce(query, 250);

    const handleEdit = (product) => {
      setEditingProduct(product);
      setShowForm(true);
    };

    const handleCloseForm = () => {
      setShowForm(false);
      setEditingProduct(null);
    };

    const handleDelete = async (id) => {
      if (confirm('Tem certeza que deseja excluir este produto?')) {
        await dbDeleteProduct(id);
        await loadData();
        showAlert('Produto excluído com sucesso!');
      }
    };

    const clearSearch = () => setQuery('');

    const filteredProducts = React.useMemo(() => {
      const term = (debouncedQuery || '').trim().toLowerCase();
      if (!term) return products;
      return (products || []).filter(p => {
        const name = (p.name || '').toLowerCase();
        const desc = (p.description || '').toLowerCase();
        const cat = (p.category || '').toLowerCase();
        const created = (p.createdAt ? new Date(p.createdAt).toLocaleDateString('pt-BR') : '').toLowerCase();
        return name.includes(term) || desc.includes(term) || cat.includes(term) || created.includes(term);
      });
    }, [products, debouncedQuery]);

    return (
      <div id="products-section" data-name="product-management" data-file="components/ProductCard.js">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h2 className="text-2xl font-bold">Produtos Cadastrados</h2>

            <div className="relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <div className="icon-search text-lg"></div>
              </div>
              <input
                type="text"
                className="input-field w-64 pl-10 pr-10"
                placeholder="Pesquisar produtos... (nome, descrição, categoria, data)"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Escape') clearSearch(); }}
              />
              {query ? (
                <button
                  onClick={clearSearch}
                  title="Limpar pesquisa"
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1 text-gray-600 hover:text-gray-800"
                >
                  <div className="icon-x text-lg"></div>
                </button>
              ) : null}
            </div>

            <button onClick={clearSearch} className="px-3 py-2 border rounded-lg text-sm hover:bg-gray-50">Limpar</button>
          </div>

          <button onClick={() => setShowForm(!showForm)} className="btn-primary">
            <span className="flex items-center gap-2">
              <div className="icon-plus text-lg"></div>
              Novo Produto
            </span>
          </button>
        </div>

        {showForm && (
          <ProductForm 
            onClose={handleCloseForm} 
            loadData={loadData} 
            showAlert={showAlert}
            editData={editingProduct}
          />
        )}

        <div className="grid gap-4 mt-6">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} onEdit={handleEdit} onDelete={handleDelete} />
          ))}
          {filteredProducts.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              Nenhum produto encontrado
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProductManagement component error:', error);
    return null;
  }
}