function LoanForm({ onClose, users, products, loadData, showAlert, editData }) {
 try {
 const [formData, setFormData] = React.useState({
 userId: editData?.userId || '',
 productId: editData?.productId || '',
 prazo: editData?.prazo ||7,
 dueDate: editData?.dueDate ? new Date(editData.dueDate).toISOString().slice(0,10) : ''
 });

 const [showUserPicker, setShowUserPicker] = React.useState(false);
 const [showProductPicker, setShowProductPicker] = React.useState(false);
 const [showUserForm, setShowUserForm] = React.useState(false);
 const [showProductForm, setShowProductForm] = React.useState(false);

 const [userPickerQuery, setUserPickerQuery] = React.useState('');
 const [productPickerQuery, setProductPickerQuery] = React.useState('');

 const userSearchRef = React.useRef(null);
 const productSearchRef = React.useRef(null);

 React.useEffect(() => {
 setFormData({
 userId: editData?.userId || '',
 productId: editData?.productId || '',
 prazo: editData?.prazo ||7,
 dueDate: editData?.dueDate ? new Date(editData.dueDate).toISOString().slice(0,10) : ''
 });
 }, [editData]);

 const availableProducts = products.filter(p => (p.quantity ||0) >0 || p.id === formData.productId);

 const handleSubmit = async (e) => {
 e.preventDefault();
 if (!formData.userId || !formData.productId) {
 showAlert('Selecione um usuário e um produto', 'error');
 return;
 }
 if (!formData.prazo || parseInt(formData.prazo,10) <=0) {
 showAlert('Informe um prazo válido (dias)', 'error');
 return;
 }

 const payload = {
 userId: formData.userId,
 productId: formData.productId,
 prazo: parseInt(formData.prazo,10)
 };
 if (formData.dueDate) payload.dueDate = formData.dueDate;

 if (editData) {
 await dbUpdateLoan(editData.id, payload);
 showAlert('Empréstimo atualizado com sucesso!');
 } else {
 await dbCreateLoan(payload);
 showAlert('Empréstimo registrado com sucesso!');
 }
 await loadData();
 onClose();
 };

 const selectUser = (id) => {
 setFormData({ ...formData, userId: id });
 setShowUserPicker(false);
 setUserPickerQuery('');
 };

 const selectProduct = (id) => {
 setFormData({ ...formData, productId: id });
 setShowProductPicker(false);
 setProductPickerQuery('');
 };

 const onUserCreated = (created) => {
 if (created && created.id) {
 setFormData({ ...formData, userId: created.id });
 setShowUserForm(false);
 loadData();
 }
 };

 const onProductCreated = (created) => {
 if (created && created.id) {
 setFormData({ ...formData, productId: created.id });
 setShowProductForm(false);
 loadData();
 }
 };

 const filteredUsersForPicker = React.useMemo(() => {
 const q = (userPickerQuery || '').trim().toLowerCase();
 if (!q) return users || [];
 const qDigits = q.replace(/\D/g, '');
 return (users || []).filter(u => {
 const name = (u.name || '').toLowerCase();
 const email = (u.email || '').toLowerCase();
 const phone = (u.phone || '').toLowerCase();
 const cpf = (u.cpf || '').replace(/\D/g, '');
 const created = u.createdAt ? new Date(u.createdAt).toLocaleDateString('pt-BR').toLowerCase() : '';
 return name.includes(q) || email.includes(q) || phone.includes(q) || created.includes(q) || (qDigits && cpf.includes(qDigits));
 });
 }, [users, userPickerQuery]);

 const filteredProductsForPicker = React.useMemo(() => {
 const q = (productPickerQuery || '').trim().toLowerCase();
 if (!q) return products || [];
 return (products || []).filter(p => {
 const name = (p.name || '').toLowerCase();
 const cat = (p.category || '').toLowerCase();
 const desc = (p.description || '').toLowerCase();
 const created = p.createdAt ? new Date(p.createdAt).toLocaleDateString('pt-BR').toLowerCase() : '';
 return name.includes(q) || cat.includes(q) || desc.includes(q) || created.includes(q);
 });
 }, [products, productPickerQuery]);

 return (
 <div id="loan-form-section" className="card p-6 mb-6" data-name="loan-form" data-file="components/LoanForm.js">
 <div className="flex items-center justify-between mb-4">
 <h3 className="text-xl font-semibold">{editData ? 'Editar Empréstimo' : 'Novo Empréstimo'}</h3>
 <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg" aria-label="Fechar">
 <div className="icon-x text-lg"></div>
 </button>
 </div>

 <form onSubmit={handleSubmit} className="space-y-4">
 <div>
 <label className="block text-sm font-medium mb-2">Usuário *</label>
 <div className="flex gap-2">
 <select
 className="input-field flex-1"
 value={formData.userId}
 onChange={(e) => setFormData({ ...formData, userId: e.target.value })}
 required
 >
 <option value="">Selecione um usuário</option>
 {users.map(user => (
 <option key={user.id} value={user.id}>{user.name}</option>
 ))}
 </select>

 <button type="button" title="Selecionar usuário" className="px-3 py-2 border rounded-lg hover:bg-gray-50" onClick={() => setShowUserPicker(true)}>Selecionar</button>
 <button type="button" title="Cadastrar usuário" className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={() => setShowUserForm(true)}>Cadastrar</button>
 </div>
 </div>

 <div>
 <label className="block text-sm font-medium mb-2">Produto *</label>
 <div className="flex gap-2">
 <select
 className="input-field flex-1"
 value={formData.productId}
 onChange={(e) => setFormData({ ...formData, productId: e.target.value })}
 required
 >
 <option value="">Selecione um produto</option>
 {availableProducts.map(product => (
 <option key={product.id} value={product.id}>{product.name}</option>
 ))}
 </select>

 <button type="button" title="Selecionar produto" className="px-3 py-2 border rounded-lg hover:bg-gray-50" onClick={() => setShowProductPicker(true)}>Selecionar</button>
 <button type="button" title="Cadastrar produto" className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={() => setShowProductForm(true)}>Cadastrar</button>
 </div>
 </div>

 <div>
 <label className="block text-sm font-medium mb-2">Prazo (dias) *</label>
 <input
 type="number"
 min="1"
 className="input-field"
 value={formData.prazo}
 onChange={(e) => setFormData({ ...formData, prazo: e.target.value })}
 required
 />
 </div>

 <div>
 <label className="block text-sm font-medium mb-2">Data de Devolução (opcional)</label>
 <input
 type="date"
 className="input-field"
 value={formData.dueDate}
 onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
 />
 </div>

 <div className="flex gap-3 pt-4">
 <button type="submit" className="btn-primary flex-1">
 {editData ? 'Atualizar Empréstimo' : 'Registrar Empréstimo'}
 </button>
 <button type="button" onClick={onClose} className="px-6 py-2.5 border rounded-lg hover:bg-gray-50">
 Cancelar
 </button>
 </div>
 </form>

 {/* User picker modal (reuse Modal component) */}
 <Modal open={showUserPicker} onClose={() => { setShowUserPicker(false); setUserPickerQuery(''); }} title="Selecionar Usuário" initialFocusRef={userSearchRef}>
 <div className="mb-4">
 <input ref={userSearchRef} type="text" className="input-field w-full" placeholder="Pesquisar usuário por nome, email, CPF..." value={userPickerQuery} onChange={(e) => setUserPickerQuery(e.target.value)} />
 </div>
 <div className="grid gap-3">
 {filteredUsersForPicker.map(u => (
 <div key={u.id} className="p-3 border rounded flex items-center justify-between">
 <div>
 <div className="font-medium">{u.name}</div>
 <div className="text-xs text-gray-500">{u.email}</div>
 </div>
 <div>
 <button onClick={() => selectUser(u.id)} className="px-3 py-2 bg-blue-600 text-white rounded">Selecionar</button>
 </div>
 </div>
 ))}
 {filteredUsersForPicker.length ===0 && (
 <div className="text-center py-8 text-gray-500">Nenhum usuário encontrado</div>
 )}
 </div>
 </Modal>

 {/* Product picker modal */}
 <Modal open={showProductPicker} onClose={() => { setShowProductPicker(false); setProductPickerQuery(''); }} title="Selecionar Produto" initialFocusRef={productSearchRef}>
 <div className="mb-4">
 <input ref={productSearchRef} type="text" className="input-field w-full" placeholder="Pesquisar produto por nome, categoria..." value={productPickerQuery} onChange={(e) => setProductPickerQuery(e.target.value)} />
 </div>
 <div className="grid gap-3">
 {filteredProductsForPicker.map(p => (
 <div key={p.id} className="p-3 border rounded flex items-center justify-between">
 <div>
 <div className="font-medium">{p.name}</div>
 <div className="text-xs text-gray-500">{p.category} — Estoque: {p.quantity ||0}</div>
 </div>
 <div>
 <button onClick={() => selectProduct(p.id)} className="px-3 py-2 bg-blue-600 text-white rounded">Selecionar</button>
 </div>
 </div>
 ))}
 {filteredProductsForPicker.length ===0 && (
 <div className="text-center py-8 text-gray-500">Nenhum produto encontrado</div>
 )}
 </div>
 </Modal>

 {/* Create user modal */}
 <Modal open={showUserForm} onClose={() => setShowUserForm(false)} title="Cadastrar Usuário">
 <UserForm onClose={() => setShowUserForm(false)} loadData={loadData} showAlert={showAlert} onCreated={onUserCreated} autoFocus={true} />
 </Modal>

 {/* Create product modal */}
 <Modal open={showProductForm} onClose={() => setShowProductForm(false)} title="Cadastrar Produto">
 <ProductForm onClose={() => setShowProductForm(false)} loadData={loadData} showAlert={showAlert} onCreated={onProductCreated} autoFocus={true} />
 </Modal>
 </div>
 );
 } catch (error) {
 console.error('LoanForm component error:', error);
 return null;
 }
}
