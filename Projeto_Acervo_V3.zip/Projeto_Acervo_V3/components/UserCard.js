function UserCard({ user, onEdit, onDelete }) {
  try {
    const formatCpfDisplay = (cpf) => {
      if (!cpf) return '';
      const digits = (cpf + '').replace(/\D/g, '');
      if (digits.length !==11) return cpf;
      return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    };

    return (
      <div className="card p-6" data-name="user-card" data-file="components/UserCard.js">
        <div className="flex items-start gap-4">
          <img 
            src={user.photo || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'} 
            alt={user.name}
            className="w-20 h-20 rounded-full object-cover"
          />
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-[var(--text-color)]">{user.name}</h3>
            <p className="text-gray-600 text-sm mt-1">{user.email}</p>
            <p className="text-gray-600 text-sm">{user.phone}</p>
            {user.cpf && (
              <p className="text-gray-600 text-sm">CPF: {formatCpfDisplay(user.cpf)}</p>
            )}
            <div className="flex items-center gap-2 mt-3">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                <div className="icon-calendar text-base text-blue-600"></div>
              </div>
              <span className="text-sm text-gray-600">
                Cadastrado em {new Date(user.createdAt).toLocaleDateString('pt-BR')}
              </span>
            </div>
          </div>
          <div className="flex gap-2 items-start">
            <button
              onClick={() => onEdit(user)}
              title="Editar"
              aria-label="Editar usuário"
              className="w-10 h-10 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center transition-colors"
            >
              <div className="icon-pencil text-lg text-blue-600"></div>
            </button>
            <button
              onClick={() => onDelete(user.id)}
              title="Excluir"
              aria-label="Excluir usuário"
              className="w-10 h-10 rounded-full bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors"
            >
              <div className="icon-trash-2 text-lg text-red-600"></div>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('UserCard component error:', error);
    return null;
  }
}

// Pequeno hook local de debounce
function useDebounce(value, delay =250) {
  const [debounced, setDebounced] = React.useState(value);
  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

function UserManagement({ users, loadData, showAlert }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [editingUser, setEditingUser] = React.useState(null);
    const [query, setQuery] = React.useState('');

    const debouncedQuery = useDebounce(query,250);

    const handleEdit = (user) => {
      setEditingUser(user);
      setShowForm(true);
    };

    const handleCloseForm = () => {
      setShowForm(false);
      setEditingUser(null);
    };

    const handleDelete = async (id) => {
      if (confirm('Tem certeza que deseja excluir este usuário?')) {
        await dbDeleteUser(id);
        await loadData();
        showAlert('Usuário excluído com sucesso!');
      }
    };

    const clearSearch = () => {
      setQuery('');
    };

    const filteredUsers = React.useMemo(() => {
      const term = (debouncedQuery || '').trim().toLowerCase();
      const termDigits = (debouncedQuery || '').replace(/\D/g, '');
      if (!term) return users;
      return (users || []).filter(u => {
        const name = (u.name || '').toLowerCase();
        const email = (u.email || '').toLowerCase();
        const phone = (u.phone || '').toLowerCase();
        const cpf = (u.cpf || '').replace(/\D/g, '');
        const created = u.createdAt ? new Date(u.createdAt).toLocaleDateString('pt-BR').toLowerCase() : '';
        return name.includes(term) || email.includes(term) || phone.includes(term) || created.includes(term) || (termDigits && cpf.includes(termDigits));
      });
    }, [users, debouncedQuery]);

    return (
      <div id="users-section" data-name="user-management" data-file="components/UserCard.js">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <h2 className="text-2xl font-bold">Usuários Cadastrados</h2>

            <div className="relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <div className="icon-search text-lg"></div>
              </div>
              <input
                type="text"
                className="input-field w-64 pl-10 pr-10"
                placeholder="Pesquisar usuários... (nome, email, telefone, CPF, data)"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Escape') clearSearch(); }}
              />
              {query ? (
                <button
                  onClick={clearSearch}
                  title="Limpar pesquisa"
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1 text-gray-600 hover:text-gray-800"
                >
                  <div className="icon-x text-lg"></div>
                </button>
              ) : null}
            </div>

            <button onClick={clearSearch} className="px-3 py-2 border rounded-lg text-sm hover:bg-gray-50">Limpar</button>
          </div>

          <button onClick={() => setShowForm(!showForm)} className="btn-primary">
            <span className="flex items-center gap-2">
              <div className="icon-plus text-lg"></div>
              Novo Usuário
            </span>
          </button>
        </div>

        {showForm && (
          <UserForm 
            onClose={handleCloseForm} 
            loadData={loadData} 
            showAlert={showAlert}
            editData={editingUser}
          />
        )}

        <div className="grid gap-4 mt-6">
          {filteredUsers.map(user => (
            <UserCard key={user.id} user={user} onEdit={handleEdit} onDelete={handleDelete} />
          ))}
          {filteredUsers.length ===0 && (
            <div className="text-center py-12 text-gray-500">
              Nenhum usuário encontrado
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('UserManagement component error:', error);
    return null;
  }
}