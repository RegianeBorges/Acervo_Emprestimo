# Sistema de Acervo de Produtos

Descri��o
---
Aplica��o front-end (React + Tailwind) para gerenciar usu�rios, produtos e empr�stimos. Dados persistidos em `localStorage` via utilit�rios em `utils/database.js`. Objetivo: sistema leve para uso local/offline com recursos de CRUD, controle de estoque, empr�stimos, devolu��es, filtros, modais acess�veis e exporta��o de relat�rios.

Instala��o e script `npm start`
---
Foi adicionado um `package.json` minimal que permite rodar um servidor est�tico local com `http-server`.

1. Instale depend�ncias (requer Node.js/NPM):

```bash
npm install
```

2. Inicie o servidor:

```bash
npm start
```

3. Abra no navegador: `http://localhost:8000`

> O script `start` executa `http-server ./ -p8000 -c-1` (sem cache). Ajuste porta conforme necess�rio.

Vis�o geral por componente
---
Abaixo h� uma descri��o de alto n�vel de cada componente principal e onde encontr�-lo.

- `index.html`
 - Entrada da aplica��o; carrega React (via CDN), Babel (para transformar JSX em runtime), Tailwind (CDN) e os scripts em `components/` e `utils/`.

- `app.js`
 - Componente `App` que inicializa dados via `utils/database.js`, controla abas (Usu�rios, Produtos, Empr�stimos, Relat�rios) e monta o `Header` e `ErrorBoundary`.

- Componentes e props principais
 ---

 - `UserForm` (`components/UserForm.js`
 - Props:
 - `onClose: () => void` � fecha o formul�rio/modal.
 - `loadData: () => Promise<void>` � fun��o para recarregar dados ap�s altera��o.
 - `showAlert: (msg: string, type?: 'success'|'error') => void` � exibe alerta.
 - `editData?: User` � se passado, formul�rio entra em modo de edi��o.
 - `onCreated?: (createdUser) => void` � callback chamado quando um novo usu�rio � criado (�til quando chamado a partir de modal picker).
 - `autoFocus?: boolean` � se true, foca o campo `name` no mount.
 - Eventos/Comportamento:
 - `handleSubmit` valida e chama `dbCreateUser` ou `dbUpdateUser`.
 - Ao criar novo usu�rio chama `onCreated(createdUser)` e `loadData()`.
 - Exemplo de uso em modal:

```jsx
<UserForm onClose={closeModal} loadData={loadData} showAlert={showAlert} onCreated={(u) => selectUser(u.id)} autoFocus={true} />
```

 - `ProductForm` (`components/ProductForm.js`)
 - Props:
 - `onClose`, `loadData`, `showAlert`, `editData?`, `onCreated?` (mesma sem�ntica do `UserForm`).
 - Eventos/Comportamento:
 - Cria/atualiza produto via `dbCreateProduct`/`dbUpdateProduct`.
 - Chama `onCreated(createdProduct)` quando for criado em modal.
 - Exemplo de uso:

```jsx
<ProductForm onClose={closeModal} loadData={loadData} showAlert={showAlert} onCreated={(p) => selectProduct(p.id)} />
```

 - `LoanForm` (`components/LoanForm.js`)
 - Props:
 - `onClose: () => void`
 - `users: User[]` � lista de usu�rios dispon�veis.
 - `products: Product[]` � lista de produtos dispon�veis.
 - `loadData: () => Promise<void>`
 - `showAlert: (msg, type?) => void`
 - `editData?: Loan` � modo edi��o.
 - Eventos/Comportamento:
 - Registra empr�stimos via `dbCreateLoan` ou atualiza via `dbUpdateLoan`.
 - Bot�es "Selecionar" abrem pickers (modais) com busca; "Cadastrar" abre `UserForm`/`ProductForm` em modal e usa `onCreated` para selecionar automaticamente o novo registro.
 - Valida disponibilidade de estoque antes de registrar (l�gica em `utils/database.js`).
 - Exemplo de uso:

```jsx
<LoanForm onClose={closeModal} users={users} products={products} loadData={loadData} showAlert={showAlert} />
```

 - `Modal` (`components/Modal.js`)
 - Props:
 - `open: boolean` � controla exibi��o.
 - `onClose: () => void` � chamado ao fechar (backdrop, Esc ou bot�o de fechar).
 - `title?: string` � t�tulo exibido no cabe�alho.
 - `children: ReactNode` � conte�do do modal.
 - `initialFocusRef?: React.RefObject<HTMLElement>` � elemento a receber foco quando modal abre.
 - `size?: string` � classes Tailwind para largura m�xima (ex.: `max-w-2xl`).
 - Eventos/Comportamento:
 - Implementa trap de foco que ignora elementos ocultos.
 - Fecha com Esc e clique no backdrop.
 - Exemplo de uso:

```jsx
<Modal open={showPicker} onClose={() => setShowPicker(false)} title="Selecionar Usu�rio" initialFocusRef={searchRef}>
 <input ref={searchRef} />
 ...lista...
</Modal>
```

 - `UserCard`, `ProductCard`, `LoanCard`
 - Props comuns:
 - `onEdit: (item) => void`
 - `onDelete: (id) => void`
 - `onReturn` (apenas `LoanCard`): `(loanId) => void`
 - Comportamento: exibem dados, bot�es de a��o e chamam handlers fornecidos.

Estrutura de arquivos (resumida)
---
- `index.html` � entrada, carrega React, Tailwind e os componentes (scripts babel).
- `app.js` � componente `App` que orquestra abas e carregamento de dados.
- `components/` � componentes da UI:
 - `Header.js`, `UserCard.js`, `UserForm.js`, `ProductCard.js`, `ProductForm.js`, `LoanCard.js`, `LoanForm.js`, `Modal.js`, `Reports.js`, `Alert.js`, etc.
- `utils/` � `database.js`, `export.js`.

Como rodar localmente
---
Recomendado: servidor est�tico local (ex.: `npm start`).

1. Instale depend�ncias:
```bash
npm install
```
2. Rode:
```bash
npm start
```
3. Abra `http://localhost:8000` no navegador.

Inicializando dados de exemplo
---
No Console do navegador execute:

```javascript
localStorage.setItem('inventory_users', JSON.stringify([{ id: 'u1', name: 'Alice', email: 'alice@example.com', createdAt: new Date().toISOString() }]));
localStorage.setItem('inventory_products', JSON.stringify([{ id: 'p1', name: 'Notebook', category: 'Eletr�nicos', quantity:5, createdAt: new Date().toISOString() }]));
localStorage.setItem('inventory_loans', JSON.stringify([]));
window.location.reload();
```

Guia passo-a-passo de testes manuais
---
Casos de teste essenciais com passos e resultados esperados.

1) Criar usu�rio
- A��o: Aba Usu�rios ? Novo Usu�rio ? preencher nome/email/CPF ? Cadastrar
- Resultado esperado: Usu�rio aparece na lista; `localStorage.inventory_users` cont�m o usu�rio.

2) Criar produto
- A��o: Aba Produtos ? Novo Produto ? preencher nome/categoria/quantidade ? Cadastrar
- Resultado esperado: Produto aparece na lista; `localStorage.inventory_products` cont�m o produto com quantidade correta.

3) Registrar empr�stimo
- Pr�-requisito: ter ao menos1 usu�rio e1 produto com `quantity >0`.
- A��o: Aba Empr�stimos ? Novo Empr�stimo ? selecionar usu�rio e produto (ou usar "Selecionar"/"Cadastrar") ? preencher prazo ? Registrar
- Resultado esperado: Empr�stimo aparece na lista de Ativos; produto `quantity` decrementou em1; `localStorage.inventory_loans` cont�m o empr�stimo com `status: 'active'`.

4) Devolver empr�stimo
- A��o: na lista de Ativos clique em "Devolver" para um empr�stimo ativo
- Resultado esperado: Empr�stimo passa para `status: 'returned'` e `returnDate` � definido; produto `quantity` incrementa em1.

5) Exportar e imprimir relat�rios
- A��o: Aba Relat�rios ? Ver Lista (por exemplo Empr�stimos Ativos) ? usar pesquisa/filtrar ? Exportar Filtrada (CSV) / Imprimir
- Resultado esperado: Arquivo CSV com colunas e linhas filtradas; impress�o mostra apenas a �rea da modal.

Depura��o / Erros comuns
---
-404 em arquivos JS: verifique `index.html` e confirme que todas as tags `<script src="..."></script>` apontam para arquivos existentes. Evite espa�os na rota do projeto.
- Aba Empr�stimos em branco: abra DevTools (F12) ? Console. Copie erros e compartilhe. O componente agora exibe um painel de erro se capturar exce��o.

Migra��o para bundler (Vite/Parcel)
---
Sugest�o para migrar de Babel-standalone para Vite (recomendado):

1. Inicialize npm se ainda n�o:
```bash
npm init -y
```

2. Instale Vite e React:
```bash
npm install --save-dev vite
npm install react react-dom
```

3. Estruture `index.html` simplificando (remova `type="text/babel"` e CDN do React). Em `index.html` importe o bundle gerado por Vite (`/src/main.jsx`).

4. Crie `src/main.jsx` que importe `App` e monte ReactDOM.

5. Ajuste `package.json` scripts:
```json
"scripts": {
 "dev": "vite",
 "build": "vite build",
 "serve": "vite preview"
}
```

6. Rode em dev: `npm run dev`.

Observa��es:
- Ser� necess�rio converter arquivos `.js` em m�dulos ES importando depend�ncias (ex.: `import React from 'react'`) e migrar para `export default` / `export` conforme necess�rio.
- Atualize refer�ncias de `components/*.js` para imports relativos (ex.: `import LoanForm from './components/LoanForm'`).

Parcel: processo similar (instalar `parcel`, criar `index.html` apontando para `src/index.js` e usar scripts `parcel`).

Melhorias poss�veis
---
- Persist�ncia mais robusta (IndexedDB ou backend).
- Testes unit�rios e e2e.
- Internacionaliza��o (i18n).
- Autentica��o/autoriza��es.
- Melhor gerenciamento de estado (Ex: Redux) para apps maiores.

Contribuindo
---
- Fa�a fork e abra PRs. Padronize c�digo com ESLint/Prettier.
- Documente novas features no README.

Licen�a
---
- Reposit�rio de exemplo � escolha a licen�a apropriada (ex.: MIT) conforme necessidade.

Contato
---
- Informa��es de contato / mantenedor: Regiane Borges - regianeborge@gmail.com.
