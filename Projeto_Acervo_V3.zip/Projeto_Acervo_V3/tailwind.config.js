/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
  "./components/**/*.{js,jsx}",
    "./app.js",
    "./index.html"
  ],
  theme: {
    extend: {
      colors: {
  primary: 'var(--primary-color)',
        secondary: 'var(--secondary-color)',
}
  },
  },
  plugins: [],
}