const DB_KEYS = {
  USERS: 'inventory_users',
  PRODUCTS: 'inventory_products',
  LOANS: 'inventory_loans'
};

function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

async function dbGetUsers() {
  try {
    const data = localStorage.getItem(DB_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting users:', error);
    return [];
  }
}

async function dbCreateUser(userData) {
  try {
    const users = await dbGetUsers();
    const newUser = {
      id: generateId(),
      ...userData,
      createdAt: new Date().toISOString()
    };
    users.push(newUser);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    return newUser;
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
}

async function dbUpdateUser(userId, userData) {
  try {
    const users = await dbGetUsers();
    const updated = users.map(u => 
      u.id === userId ? { ...u, ...userData } : u
    );
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(updated));
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
}

async function dbDeleteUser(userId) {
  try {
    const users = await dbGetUsers();
    const filtered = users.filter(u => u.id !== userId);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
}

async function dbGetProducts() {
  try {
    const data = localStorage.getItem(DB_KEYS.PRODUCTS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting products:', error);
    return [];
  }
}

async function dbCreateProduct(productData) {
  try {
    const products = await dbGetProducts();
    const newProduct = {
      id: generateId(),
      ...productData,
      quantity: productData.quantity || 0,
      createdAt: new Date().toISOString()
    };
    products.push(newProduct);
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(products));
    return newProduct;
  } catch (error) {
    console.error('Error creating product:', error);
    throw error;
  }
}

async function dbUpdateProduct(productId, productData) {
  try {
    const products = await dbGetProducts();
    const updated = products.map(p => 
      p.id === productId ? { ...p, ...productData } : p
    );
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(updated));
  } catch (error) {
    console.error('Error updating product:', error);
    throw error;
  }
}

async function dbDeleteProduct(productId) {
  try {
    const products = await dbGetProducts();
    const filtered = products.filter(p => p.id !== productId);
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error deleting product:', error);
    throw error;
  }
}

async function dbGetLoans() {
  try {
    const data = localStorage.getItem(DB_KEYS.LOANS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting loans:', error);
    return [];
  }
}

async function dbCreateLoan(loanData) {
  try {
    const loans = await dbGetLoans();
    const products = await dbGetProducts();
    
    const product = products.find(p => p.id === loanData.productId);
    if (!product || (product.quantity || 0) <= 0) {
      throw new Error('Produto indisponível em estoque');
    }
    
    const loanDate = new Date();
    let dueDateIso = null;
    if (loanData.dueDate) {
      dueDateIso = new Date(loanData.dueDate).toISOString();
    } else if (loanData.prazo) {
      const prazoDays = parseInt(loanData.prazo, 10) || 0;
      const dueDate = new Date(loanDate.getTime() + prazoDays * 24 * 60 * 60 * 1000);
      dueDateIso = dueDate.toISOString();
    }
    
    const newLoan = {
      id: generateId(),
      ...loanData,
      prazo: loanData.prazo ? parseInt(loanData.prazo, 10) : undefined,
      dueDate: dueDateIso,
      status: 'active',
      loanDate: loanDate.toISOString()
    };
    
    loans.push(newLoan);
    localStorage.setItem(DB_KEYS.LOANS, JSON.stringify(loans));
    
    const updatedProducts = products.map(p => 
      p.id === loanData.productId ? { ...p, quantity: (p.quantity || 0) - 1 } : p
    );
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(updatedProducts));
    
    return newLoan;
  } catch (error) {
    console.error('Error creating loan:', error);
    throw error;
  }
}

async function dbUpdateLoan(loanId, loanData) {
  try {
    const loans = await dbGetLoans();
    const products = await dbGetProducts();

    const original = loans.find(l => l.id === loanId);
    if (!original) throw new Error('Empréstimo não encontrado');

    // Normalize date fields if provided
    if (loanData.dueDate) {
      try { loanData.dueDate = new Date(loanData.dueDate).toISOString(); } catch (e) { /* ignore */ }
    }
    if (loanData.returnDate) {
      try { loanData.returnDate = new Date(loanData.returnDate).toISOString(); } catch (e) { /* ignore */ }
    }

    // Clone products to modify
    const updatedProducts = products.map(p => ({ ...p }));

    // Handle product change
    if (loanData.productId && loanData.productId !== original.productId) {
      const oldProd = updatedProducts.find(p => p.id === original.productId);
      const newProd = updatedProducts.find(p => p.id === loanData.productId);
      if (!newProd) throw new Error('Produto destino não encontrado');

      // If original was active, return one to old product stock
      if (original.status === 'active') {
        if (oldProd) oldProd.quantity = (oldProd.quantity || 0) + 1;

        if ((newProd.quantity || 0) <= 0) {
          throw new Error('Produto destino indisponível em estoque');
        }
        newProd.quantity = (newProd.quantity || 0) - 1;
      } else {
        // If original was returned and updated loan will be active, decrement new product
        if ((loanData.status || original.status) === 'active') {
          if ((newProd.quantity || 0) <= 0) {
            throw new Error('Produto destino indisponível em estoque');
          }
          newProd.quantity = (newProd.quantity || 0) - 1;
        }
      }
    }

    // Handle status change to returned -> increment product stock if it was active
    if (loanData.status === 'returned' && original.status === 'active') {
      const prod = updatedProducts.find(p => p.id === original.productId);
      if (prod) prod.quantity = (prod.quantity || 0) + 1;
      // ensure returnDate
      if (!loanData.returnDate) loanData.returnDate = new Date().toISOString();
    }

    // Handle status change from returned to active -> decrement product stock
    if (loanData.status === 'active' && original.status === 'returned') {
      const prod = updatedProducts.find(p => p.id === (loanData.productId || original.productId));
      if (prod) {
        if ((prod.quantity || 0) <= 0) throw new Error('Produto indisponível em estoque');
        prod.quantity = (prod.quantity || 0) - 1;
      }
    }

    const updatedLoans = loans.map(l => 
      l.id === loanId ? { ...l, ...loanData, prazo: loanData.prazo ? parseInt(loanData.prazo, 10) : l.prazo } : l
    );

    localStorage.setItem(DB_KEYS.LOANS, JSON.stringify(updatedLoans));
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(updatedProducts));

    return updatedLoans.find(l => l.id === loanId);
  } catch (error) {
    console.error('Error updating loan:', error);
    throw error;
  }
}

async function dbReturnLoan(loanId) {
  try {
    const loans = await dbGetLoans();
    const products = await dbGetProducts();
    
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return;
    
    const updatedLoans = loans.map(l => 
      l.id === loanId ? { ...l, status: 'returned', returnDate: new Date().toISOString() } : l
    );
    localStorage.setItem(DB_KEYS.LOANS, JSON.stringify(updatedLoans));
    
    const updatedProducts = products.map(p => 
      p.id === loan.productId ? { ...p, quantity: (p.quantity || 0) + 1 } : p
    );
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(updatedProducts));
  } catch (error) {
    console.error('Error returning loan:', error);
    throw error;
  }
}

async function dbDeleteLoan(loanId) {
  try {
    const loans = await dbGetLoans();
    const products = await dbGetProducts();

    const loan = loans.find(l => l.id === loanId);
    if (!loan) return;

    // If loan is active, return product to stock
    if (loan.status === 'active') {
      const updatedProducts = products.map(p => 
        p.id === loan.productId ? { ...p, quantity: (p.quantity || 0) + 1 } : p
      );
      localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(updatedProducts));
    }

    const filtered = loans.filter(l => l.id !== loanId);
    localStorage.setItem(DB_KEYS.LOANS, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error deleting loan:', error);
    throw error;
  }
}
