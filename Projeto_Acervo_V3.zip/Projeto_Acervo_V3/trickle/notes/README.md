# Sistema de Acervo de Produtos

Sistema completo para gerenciamento de acervo de produtos com controle de empréstimos.

## Funcionalidades

### Gerenciamento de Usuários
- Cadastro de novos usuários com informações pessoais
- Upload de foto de perfil
- Visualização e exclusão de usuários
- Campos: nome, email, telefone, foto

### Gerenciamento de Produtos
- Cadastro de produtos no acervo
- Upload de foto do produto
- Controle de quantidade em estoque
- Status automático baseado na quantidade disponível
- Campos: nome, descrição, categoria, quantidade, foto

### Controle de Empréstimos
- Registro de empréstimos de produtos para usuários
- Controle automático de estoque (diminui ao emprestar, aumenta ao devolver)
- Bloqueio automático quando estoque chega a zero
- Visualização de empréstimos ativos e histórico
- Sistema de devolução de produtos

### Relatórios e Exportação
- Visualização de estatísticas gerais
- Exportação de usuários em JSON e CSV
- Exportação de produtos em JSON e CSV
- Exportação de empréstimos ativos em JSON e CSV
- Exportação de devoluções (histórico) em JSON e CSV

## Estrutura Técnica

### Componentes
- **Header**: Navegação entre seções
- **UserCard/UserForm**: Gerenciamento de usuários
- **ProductCard/ProductForm**: Gerenciamento de produtos
- **LoanCard/LoanForm**: Gerenciamento de empréstimos
- **Reports**: Relatórios e exportação de dados
- **Alert**: Notificações para o usuário

### Armazenamento
- Utiliza localStorage para persistência de dados
- Três coleções principais: usuários, produtos e empréstimos

## Status do Projeto

✅ Sistema funcional e pronto para uso
✅ Interface responsiva e intuitiva
✅ Validações de formulário implementadas
✅ Controle automático de estoque de produtos
✅ Bloqueio de empréstimos quando estoque zerado
✅ Histórico de empréstimos
✅ Exportação de dados em JSON e CSV
