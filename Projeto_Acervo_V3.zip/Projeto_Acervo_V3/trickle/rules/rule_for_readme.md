When making updates to the project

- Always check if the README.md in trickle/notes needs to be updated
- Update README.md if new features are added
- Update README.md if the project structure changes significantly
- Update README.md if dependencies or requirements change
- Keep the README concise and focused on essential information